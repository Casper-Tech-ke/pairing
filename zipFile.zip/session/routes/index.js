const qrRoute = require('./qr');
const pairRoute = require('./pair');

module.exports = {
    qrRoute,
    pairRoute
}